package br.com.prog3.aula13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
