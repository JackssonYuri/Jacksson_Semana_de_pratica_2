package br.com.prog3.aula13.dto;

import java.time.LocalDate;

import br.com.prog3.aula13.domain.Cliente;

public class ClienteDTO {
	
	private Long id;
	private String cpf;
	private String nome;
	private LocalDate dataNascimento;
	public ClienteDTO(Cliente cliente) {
		this.setId(cliente.getId());
		this.setCpf(Cliente.getCpf());
		this.setNome(Cliente.getNome());
		this.setDataNascimento(Cliente.getDataNascimento());
		}
	public LocalDate getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	

}
