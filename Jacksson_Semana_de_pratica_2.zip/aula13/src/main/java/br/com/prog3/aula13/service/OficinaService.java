package br.com.prog3.aula13.service;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import antlr.collections.List;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.domain.Oficina;
import br.com.prog3.aula13.dto.ClienteDTO;
import br.com.prog3.aula13.repository.ClienteRepository;
import br.com.prog3.aula13.repository.OficinaRepository;

@Service
public class OficinaService {

	@Autowired
	private OficinaRepository oficinaRepository;

	public OficinaRepository getOficinaRepository() {
		return oficinaRepository;
	}

	public void setOficinaRepository(OficinaRepository oficinaRepository) {
		this.oficinaRepository = oficinaRepository;
	}

	public List findAll() {
		return (List) ((Optional<Oficina>) oficinaRepository.findAll()).stream().map(cliente -> new ClienteDTO(cliente)).collect(Collectors.toList());
	}
	
	public static Optional<Oficina> findByPlaca(Integer Codigo) {
		return OficinaRepository.findById(Codigo);
	}
	
	
	public Oficina update(Oficina oficina) {
		return oficinaRepository.save(oficina);
	}
	
	public void deleteById(Long id) {
		oficinaRepository.deleteById(id);
	}
}
