package br.com.prog3.aula13.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Oficina {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private static int codigo;
	private static String especialidade;
	private static String endereco;
	
	@OneToMany(cascade = CascadeType.ALL)
	List<Carro> carros;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public static int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		Oficina.codigo = codigo;
	}

	public static String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		Oficina.especialidade = especialidade;
	}

	public static String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		Oficina.endereco = endereco;
	}

	public List<Carro> getCarros() {
		return carros;
	}

	public void setCarros(List<Carro> carros) {
		this.carros = carros;
	}

	public static boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public static Object getNome() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setNome(Object nome) {
		// TODO Auto-generated method stub
		
	}
	
	
}
