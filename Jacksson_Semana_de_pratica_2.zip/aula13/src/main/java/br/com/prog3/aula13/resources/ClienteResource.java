package br.com.prog3.aula13.resources;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import antlr.collections.List;
import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.service.ClienteService;

@RestController
@RequestMapping("api/v1/cliente")
public class ClienteResource {
	
	@Autowired
	private ClienteService clienteService;
	private Cliente cliente;
	private Cliente c;
	
	@GetMapping
	public ResponseEntity<List> findAll() {
	List clientes = clienteService.findAll();
	cliente = null;
	if (clientes == null || ((Cliente) cliente).isEmpty()) {
	return new
	ResponseEntity<List>(HttpStatus.NO_CONTENT);
	}
	return null;
	}
	@GetMapping(path = {"/{cpf}"})
	public Optional<Cliente> findById(@PathVariable("cpf") String cpf){
	return ClienteService.findByPlaca(cpf);
	}
	@PutMapping(value="/{id}")
	public Cliente update(@PathVariable("id") Long id, @RequestBody Carro carro) {
	String cpf = null;
	Optional<Cliente> optional = ClienteService.findByPlaca(cpf);
	if(optional.isPresent()) {
		c = null;
		c.setCpf(Cliente.getCpf());
		c.setNome(Cliente.getNome());
		c.setDataNascimento(Cliente.getDataNascimento());
	
		clienteService.update(c);
	clienteService.update(c);
	return c;
	}else {
	throw new RuntimeException("Não foi possível alterar registro");
	}
	}
	
	@DeleteMapping(path ={"/{id}"})
	public void delete(@PathVariable("id") Long id) {
	clienteService.deleteById(id);
	}	
	
	
	public ClienteService getClienteService() {
		return clienteService;
	}

	public void setClienteService(ClienteService clienteService) {
		this.clienteService = clienteService;
	}

	@PutMapping
	public Cliente put(@RequestParam("cpf") String cpf) {
		Cliente cliente = new Cliente();
		cliente.setCpf(cpf);
		return cliente;
	}

}
