package br.com.prog3.aula13.resources;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import antlr.collections.List;
import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.service.CarroService;

@RestController
@RequestMapping("api/v1/carro")
public class CarroResource<CarroDTO> {
	
	
	
	
	@PostMapping
	public String save(@RequestParam("placa") String placa,
			@RequestParam("cor") String cor,
			@RequestParam("ano") int ano,
			@RequestParam("anoModelo") int anoModelo,
			@RequestParam("marca") String marca,
			@RequestParam("modelo") String modelo) {
		
		Carro carro = new Carro();
		carro.setCor(cor);
		carro.setPlaca(placa);
		carro.setAno(ano);
		carro.setModelo(modelo);
		carro.setMarca(marca);
		carro.setAnoModelo(anoModelo);
		carroService.save(carro);
		
		return "Ok";
	}
	
	@Autowired
	private CarroService carroService;
	@GetMapping
	public ResponseEntity<List> findAll() {
	List carros = 	carroService.findAll();
	if (	carros == null || Carro.isEmpty()) {
	return new
	ResponseEntity<List>(HttpStatus.NO_CONTENT);
	}
	return null;
	}
	@GetMapping(path = {"/{id}"})
	public Optional<Carro> findById(@PathVariable("id") Long id){
	return CarroService.findByPlaca(id);
	}
	@PutMapping(value="/{id}")
	public Carro update(@PathVariable("id") Long id, @RequestBody Carro
	carro) {
	Optional<Carro> optional = CarroService.findByPlaca(id);
	if(optional.isPresent()) {
	Carro c = optional.get();
	c.setPlaca(Carro.getPlaca());
		c.setCor(Carro.getCor());
		c.setAno(Carro.getAno());
		c.setAnoModelo(Carro.getAnoModelo());
		c.setMarca(Carro.getMarca());
		c.setModelo(Carro.getModelo());
		carroService.update(c);
	carroService.update(c);
	return c;
	}else {
	throw new RuntimeException("Não foi possível alterar registro");
	}
	}
	
	@DeleteMapping(path ={"/{id}"})
	public void delete(@PathVariable("id") Long id) {
	carroService.deleteById(id);
	}
	
	public CarroService getCarroService() {
		return carroService;
	}

	public void setCarroService(CarroService carroService) {
		this.carroService = carroService;
	}
}
