package br.com.prog3.aula13.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Carro {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private static String placa;
	private static String cor;
	private static Integer ano;
	private static Integer anoModelo;
	private static String marca;
	private static String modelo;
	
	@ManyToOne
	private Cliente cliente;
	
	@ManyToOne
	private Oficina oficina;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public static String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		Carro.placa = placa;
	}

	public static String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		Carro.cor = cor;
	}

	public static Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		Carro.ano = ano;
	}

	public static Integer getAnoModelo() {
		return anoModelo;
	}

	public void setAnoModelo(Integer anoModelo) {
		Carro.anoModelo = anoModelo;
	}

	public static String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		Carro.marca = marca;
	}

	public static String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		Carro.modelo = modelo;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Oficina getOficina() {
		return oficina;
	}

	public void setOficina(Oficina oficina) {
		this.oficina = oficina;
	}

	public static boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}		
}
