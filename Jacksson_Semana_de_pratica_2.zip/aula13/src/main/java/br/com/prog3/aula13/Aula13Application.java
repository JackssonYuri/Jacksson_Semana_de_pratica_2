package br.com.prog3.aula13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula13Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula13Application.class, args);
	}

}
