package br.com.prog3.aula13.dto;

import br.com.prog3.aula13.domain.Carro;

public class CarroDTO {
		private Long id;
		private String placa;
		private String cor;
		private Integer ano;
		private Integer anoModelo;
		private String marca;
		private String modelo;
	public CarroDTO(Carro carro) {
		this.id = carro.getId();
		this.placa = Carro.getPlaca();
		this.cor = Carro.getCor();
		this.ano = Carro.getAno();
		this.anoModelo = Carro.getAnoModelo();
		this.marca = Carro.getMarca();
		this.modelo = Carro.getModelo();
		}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public Integer getAno() {
		return ano;
	}
	public void setAno(Integer ano) {
		this.ano = ano;
	}
	public Integer getAnoModelo() {
		return anoModelo;
	}
	public void setAnoModelo(Integer anoModelo) {
		this.anoModelo = anoModelo;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
}


