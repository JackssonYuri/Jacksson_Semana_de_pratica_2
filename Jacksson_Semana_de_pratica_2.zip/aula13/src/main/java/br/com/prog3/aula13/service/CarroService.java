package br.com.prog3.aula13.service;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import antlr.collections.List;
import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.dto.CarroDTO;
import br.com.prog3.aula13.repository.CarroRepository;

@Service
public class CarroService {

	@Autowired
	private CarroRepository carroRepository;

	public void save(Carro carro) {
		carroRepository.save(carro);
	}
	
	public List findAll(){
		return carroRepository.findAll().stream().map(carro -> new CarroDTO(carro)).collect(Collectors.toList());
		}
	
	public static Optional<Carro> findByPlaca(Long id) {
		return CarroRepository.findByPlaca(id);
	}
	
	
	public Carro update(Carro carro) {
		return carroRepository.save(carro);
	}
		
	public void deleteById(Long id) {
		carroRepository.deleteById(id);
	}
		
	
	public CarroRepository getCarroRepository() {
		return carroRepository;
	}

	public void setCarroRepository(CarroRepository carroRepository) {
		this.carroRepository = carroRepository;
	}
}
