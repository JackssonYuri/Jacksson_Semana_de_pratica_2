package br.com.prog3.aula13.service;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import antlr.collections.List;
import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.repository.CarroRepository;
import br.com.prog3.aula13.repository.ClienteRepository;

@Service
public class ClienteService {

	@Autowired
	private ClienteRepository clienteRepository;

	public ClienteRepository getClienteRepository() {
		return clienteRepository;
	}

	public void setClienteRepository(ClienteRepository clienteRepository) {
		this.clienteRepository = clienteRepository;
	}

	public List findAll() {
		return clienteRepository.findAll().stream().map(cliente -> new ClienteDTO(cliente)).collect(Collectors.toList());
	}
	
	public static Optional<Cliente> findByPlaca(String Cpf) {
		return ClienteRepository.findById(Cpf);
	}
	
	
	public Cliente update(Cliente cliente) {
		return clienteRepository.save(cliente);
	}
	
	public void deleteById(Long id) {
		clienteRepository.deleteById(id);
	}
		
		
	
}
