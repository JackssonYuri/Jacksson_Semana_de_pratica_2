package br.com.prog3.aula13.resources;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import antlr.collections.List;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.domain.Oficina;
import br.com.prog3.aula13.service.ClienteService;
import br.com.prog3.aula13.service.OficinaService;

@RestController
@RequestMapping("api/v1/oficina")
public class OficionaResource {
	
	private static final int Integer = 0;
	@Autowired
	private OficinaService oficinaService;
	private Oficina o;

	public OficinaService getOficinaService() {
		return oficinaService;
	}

	public void setOficinaService(OficinaService oficinaService) {
		this.oficinaService = oficinaService;
	}
	
	@GetMapping
	public ResponseEntity<List> findAll() {
	List oficinas = 	oficinaService.findAll();
	if (	oficinas == null || Oficina.isEmpty()) {
	return new
	ResponseEntity<List>(HttpStatus.NO_CONTENT);
	}
	return null;
	}
	@GetMapping(path = {"/{codigo}"})
	public Optional<Oficina> findById(@PathVariable("id") Integer codigo){
	return OficinaService.findByPlaca(codigo);
	}
	@PutMapping(value="/{codigo}")
	public Oficina update(@PathVariable("codigo") Long id, @RequestBody Oficina oficina) {
	String cpf = null;
	Optional<Cliente> optional = ClienteService.findByPlaca(cpf);
	if(optional.isPresent()) {
		o = null;
		o.setCodigo(Oficina.getCodigo());
		o.setNome(Oficina.getNome());
		o.setEspecialidade(Oficina.getEspecialidade());
		o.setEndereco(Oficina.getEndereco());
	
		oficinaService.update(o);
		oficinaService.update(o);
	return o;
	}else {
	throw new RuntimeException("Não foi possível alterar registro");
	}
	}
	

	@PutMapping
	public Oficina put(@RequestParam("codigo") Integer codigo) {
		Oficina oficina = new Oficina();
		oficina.setCodigo(Integer);
		return oficina;
	}
	
}
