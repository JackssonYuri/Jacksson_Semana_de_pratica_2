package br.com.prog3.aula13.domain;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Cliente {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private static String cpf;
	private static String nome;
	private static LocalDate dataNascimento;
	
	@OneToMany(cascade = CascadeType.ALL)
	List<Carro> carros;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public List<Carro> getCarros() {
		return carros;
	}
	public void setCarros(List<Carro> carros) {
		this.carros = carros;
	}
	public static String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		Cliente.cpf = cpf;
	}
	public static String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		Cliente.nome = nome;
	}
	public static LocalDate getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(LocalDate dataNascimento) {
		Cliente.dataNascimento = dataNascimento;
	}
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}
}
